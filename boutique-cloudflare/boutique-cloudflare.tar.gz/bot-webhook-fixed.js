require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const express = require('express');
const mongoose = require('mongoose');
const axios = require('axios');
const fs = require('fs-extra');
const { loadConfig, saveConfig, getImagePath } = require('./config');
const { getMainKeyboard, getAdminKeyboard, getSocialManageKeyboard, getSocialLayoutKeyboard, getConfirmKeyboard } = require('./keyboards');

// Configuration Express
const app = express();
const PORT = process.env.PORT || 3000;

// Vérifier les variables d'environnement
if (!process.env.BOT_TOKEN) {
    console.error('❌ BOT_TOKEN n\'est pas défini dans le fichier .env');
    process.exit(1);
}

if (!process.env.ADMIN_ID) {
    console.error('❌ ADMIN_ID n\'est pas défini dans le fichier .env');
    process.exit(1);
}

// Configuration du webhook
const WEBHOOK_URL = process.env.WEBHOOK_URL || 
                    process.env.RENDER_EXTERNAL_URL || 
                    process.env.RAILWAY_PUBLIC_DOMAIN ||
                    process.env.VERCEL_URL ||
                    'https://your-app.onrender.com';
const WEBHOOK_PATH = `/bot${process.env.BOT_TOKEN}`;

// Initialiser le bot en mode webhook
const bot = new TelegramBot(process.env.BOT_TOKEN, { 
    webHook: {
        port: PORT,
        autoOpen: false
    }
});
const ADMIN_ID = parseInt(process.env.ADMIN_ID);

// Middleware Express
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// État des utilisateurs (pour gérer les conversations)
const userStates = {};
// Stocker l'ID du dernier message pour chaque chat (un seul message actif par chat)
const activeMessages = {};
// Stocker les utilisateurs qui ont interagi avec le bot
const users = new Set();
// Stocker les administrateurs
const admins = new Set([ADMIN_ID]);

// Temps de démarrage du bot
const botStartTime = new Date();

// Configuration globale (sera chargée depuis MongoDB)
let config = {};

// Routes Express
app.get('/', (req, res) => {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    
    res.send(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Bot Telegram - Dashboard</title>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body {
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    min-height: 100vh;
                    margin: 0;
                }
                .container {
                    background: rgba(255, 255, 255, 0.1);
                    backdrop-filter: blur(10px);
                    border-radius: 20px;
                    padding: 40px;
                    box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
                    text-align: center;
                    max-width: 500px;
                }
                h1 { margin: 0 0 20px 0; }
                .status { 
                    background: #10b981;
                    display: inline-block;
                    padding: 8px 16px;
                    border-radius: 20px;
                    margin: 10px 0;
                }
                .stats {
                    margin-top: 30px;
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 20px;
                }
                .stat {
                    background: rgba(255, 255, 255, 0.1);
                    padding: 15px;
                    border-radius: 10px;
                }
                .value { font-size: 24px; font-weight: bold; }
                .label { opacity: 0.8; margin-top: 5px; }
            </style>
        </head>
        <body>
            <div class="container">
                <h1>🤖 Bot Telegram</h1>
                <div class="status">✅ En ligne</div>
                <div class="stats">
                    <div class="stat">
                        <div class="value">${hours}h ${minutes}m ${seconds}s</div>
                        <div class="label">Temps de fonctionnement</div>
                    </div>
                    <div class="stat">
                        <div class="value">${new Date().toLocaleTimeString()}</div>
                        <div class="label">Heure serveur</div>
                    </div>
                    <div class="stat">
                        <div class="value">${users.size}</div>
                        <div class="label">Utilisateurs</div>
                    </div>
                    <div class="stat">
                        <div class="value">${admins.size}</div>
                        <div class="label">Administrateurs</div>
                    </div>
                </div>
            </div>
        </body>
        </html>
    `);
});

// Route de santé pour monitoring
app.get('/health', async (req, res) => {
    try {
        const dbStatus = mongoose.connection.readyState === 1 ? 'connected' : 'disconnected';
        const botInfo = await bot.getMe().catch(() => null);
        
        res.json({ 
            status: 'healthy',
            bot: botInfo ? 'active' : 'checking',
            database: dbStatus,
            timestamp: new Date().toISOString(),
            uptime: process.uptime(),
            users: users.size,
            admins: admins.size,
            webhook: WEBHOOK_URL + WEBHOOK_PATH
        });
    } catch (error) {
        res.status(500).json({ 
            status: 'error',
            message: error.message,
            timestamp: new Date().toISOString()
        });
    }
});

// Route pour le webhook Telegram
app.post(WEBHOOK_PATH, (req, res) => {
    try {
        bot.processUpdate(req.body);
        res.sendStatus(200);
    } catch (error) {
        console.error('Erreur traitement webhook:', error);
        res.sendStatus(500);
    }
});

// Route pour vérifier le webhook
app.get('/webhook-info', async (req, res) => {
    try {
        const info = await bot.getWebHookInfo();
        res.json(info);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Système de keep-alive automatique
let keepAliveInterval;

function startKeepAlive() {
    if (process.env.NODE_ENV === 'production' || process.env.ENABLE_KEEPALIVE === 'true') {
        console.log('🔄 Activation du système keep-alive');
        
        keepAliveInterval = setInterval(async () => {
            try {
                const url = `${WEBHOOK_URL}/health`;
                const response = await axios.get(url, { timeout: 5000 });
                console.log(`✅ Keep-alive ping: ${response.data.status}`);
            } catch (error) {
                console.error('❌ Erreur keep-alive:', error.message);
            }
        }, 5 * 60 * 1000); // 5 minutes
    }
}

// Schéma MongoDB pour les utilisateurs
const userSchema = new mongoose.Schema({
    userId: { type: Number, required: true, unique: true },
    username: String,
    firstName: String,
    lastName: String,
    isAdmin: { type: Boolean, default: false },
    firstSeen: { type: Date, default: Date.now },
    lastSeen: { type: Date, default: Date.now }
});

const User = mongoose.model('BotUser', userSchema);

// Charger la configuration au démarrage
async function initializeBot() {
    try {
        // Connexion MongoDB
        if (process.env.MONGODB_URI) {
            try {
                await mongoose.connect(process.env.MONGODB_URI, {
                    useNewUrlParser: true,
                    useUnifiedTopology: true
                });
                console.log('✅ Connecté à MongoDB');
                
                // Charger les utilisateurs depuis MongoDB
                const dbUsers = await User.find();
                dbUsers.forEach(user => {
                    users.add(user.userId);
                    if (user.isAdmin) {
                        admins.add(user.userId);
                    }
                });
                console.log(`✅ ${users.size} utilisateurs chargés depuis MongoDB`);
            } catch (error) {
                console.log('⚠️ MongoDB non disponible, mode local activé');
            }
        }
        
        // Charger la configuration
        config = await loadConfig();
        console.log('✅ Configuration chargée');
        
        // Supprimer l'ancien webhook s'il existe
        await bot.deleteWebHook();
        
        // Configurer le nouveau webhook
        const webhookUrl = `${WEBHOOK_URL}${WEBHOOK_PATH}`;
        const webhookOptions = {
            max_connections: 100,
            allowed_updates: ['message', 'callback_query', 'inline_query', 'my_chat_member']
        };
        
        await bot.setWebHook(webhookUrl, webhookOptions);
        console.log(`🔗 Webhook configuré: ${webhookUrl}`);
        
        // Vérifier le webhook
        const webhookInfo = await bot.getWebHookInfo();
        console.log('📊 Info webhook:', {
            url: webhookInfo.url,
            pending: webhookInfo.pending_update_count,
            last_error: webhookInfo.last_error_message
        });
        
        // Démarrer le keep-alive
        startKeepAlive();
        
    } catch (error) {
        console.error('❌ Erreur initialisation:', error);
        // Réessayer après 10 secondes
        setTimeout(initializeBot, 10000);
    }
}

// Sauvegarder un utilisateur dans MongoDB
async function saveUser(userId, userInfo = {}) {
    try {
        await User.findOneAndUpdate(
            { userId },
            {
                userId,
                username: userInfo.username,
                firstName: userInfo.first_name,
                lastName: userInfo.last_name,
                lastSeen: new Date()
            },
            { upsert: true, new: true }
        );
        users.add(userId);
    } catch (error) {
        console.error('Erreur sauvegarde utilisateur:', error);
    }
}

// Fonction pour supprimer tous les messages actifs d'un chat
async function deleteActiveMessage(chatId) {
    if (activeMessages[chatId]) {
        try {
            await bot.deleteMessage(chatId, activeMessages[chatId]);
        } catch (error) {
            // Ignorer si le message est déjà supprimé
        }
        delete activeMessages[chatId];
    }
}

// Fonction pour envoyer un message et supprimer l'ancien
async function sendNewMessage(chatId, text, options = {}) {
    // Supprimer l'ancien message actif
    await deleteActiveMessage(chatId);
    
    // Envoyer le nouveau message
    try {
        const message = await bot.sendMessage(chatId, text, options);
        activeMessages[chatId] = message.message_id;
        return message;
    } catch (error) {
        console.error('Erreur lors de l\'envoi du message:', error);
    }
}

// Fonction pour envoyer une photo et supprimer l'ancien message
async function sendNewPhoto(chatId, photo, options = {}) {
    // Supprimer l'ancien message actif
    await deleteActiveMessage(chatId);
    
    // Envoyer la nouvelle photo
    try {
        const message = await bot.sendPhoto(chatId, photo, options);
        activeMessages[chatId] = message.message_id;
        return message;
    } catch (error) {
        console.error('Erreur lors de l\'envoi de la photo:', error);
    }
}

// Fonction pour éditer le message actif ou en envoyer un nouveau
async function updateMessage(chatId, messageId, text, options = {}) {
    try {
        // Vérifier si c'est bien le message actif
        if (activeMessages[chatId] === messageId) {
            await bot.editMessageText(text, {
                chat_id: chatId,
                message_id: messageId,
                ...options
            });
            return { message_id: messageId };
        } else {
            // Si ce n'est pas le message actif, envoyer un nouveau message
            return await sendNewMessage(chatId, text, options);
        }
    } catch (error) {
        // En cas d'erreur, envoyer un nouveau message
        return await sendNewMessage(chatId, text, options);
    }
}

// Fonction pour envoyer le message d'accueil
async function sendWelcomeMessage(chatId, editMessageId = null, userInfo = null) {
    try {
        // Personnaliser le message avec le nom de l'utilisateur
        let personalizedMessage = config.welcomeMessage || 'Bienvenue !';
        
        // Si on a les infos de l'utilisateur, remplacer les variables
        if (userInfo) {
            personalizedMessage = personalizedMessage
                .replace(/{firstname}/gi, userInfo.first_name || '')
                .replace(/{lastname}/gi, userInfo.last_name || '')
                .replace(/{username}/gi, userInfo.username ? `@${userInfo.username}` : '')
                .replace(/{fullname}/gi, `${userInfo.first_name || ''} ${userInfo.last_name || ''}`.trim());
        }
        
        const options = {
            reply_markup: getMainKeyboard(config),
            parse_mode: 'HTML'
        };

        if (config.welcomeImage) {
            const imagePath = getImagePath(config.welcomeImage);
            if (fs.existsSync(imagePath)) {
                // Avec image, on doit envoyer un nouveau message
                await sendNewPhoto(chatId, imagePath, {
                    caption: personalizedMessage,
                    ...options
                });
            } else {
                // Sans image valide, utiliser du texte
                if (editMessageId && activeMessages[chatId] === editMessageId) {
                    await updateMessage(chatId, editMessageId, personalizedMessage, options);
                } else {
                    await sendNewMessage(chatId, personalizedMessage, options);
                }
            }
        } else {
            // Sans image, on peut éditer ou envoyer un nouveau message
            if (editMessageId && activeMessages[chatId] === editMessageId) {
                await updateMessage(chatId, editMessageId, personalizedMessage, options);
            } else {
                await sendNewMessage(chatId, personalizedMessage, options);
            }
        }
    } catch (error) {
        console.error('Erreur lors de l\'envoi du message d\'accueil:', error);
        await sendNewMessage(chatId, '❌ Une erreur s\'est produite. Veuillez réessayer.');
    }
}

// Commande /start
bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    
    // Ajouter l'utilisateur à la liste
    await saveUser(userId, msg.from);
    
    // Supprimer le message de commande
    try {
        await bot.deleteMessage(chatId, msg.message_id);
    } catch (error) {}
    
    // Envoyer le message d'accueil avec les infos de l'utilisateur
    await sendWelcomeMessage(chatId, null, msg.from);
});

// Commande /id pour obtenir son ID
bot.onText(/\/id/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const username = msg.from.username ? `@${msg.from.username}` : 'Non défini';
    const firstName = msg.from.first_name;
    const lastName = msg.from.last_name || '';
    
    // Supprimer le message de commande
    try {
        await bot.deleteMessage(chatId, msg.message_id);
    } catch (error) {}
    
    const idMessage = `🆔 **Vos informations**\n\n` +
        `👤 **Nom:** ${firstName} ${lastName}\n` +
        `📛 **Username:** ${username}\n` +
        `🔢 **ID Telegram:** \`${userId}\`\n\n` +
        `_Vous pouvez copier votre ID en cliquant dessus_`;
    
    await sendNewMessage(chatId, idMessage, {
        parse_mode: 'Markdown',
        reply_markup: {
            inline_keyboard: [[
                { text: '❌ Fermer', callback_data: 'admin_close' }
            ]]
        }
    });
});

// Commande /admin
bot.onText(/\/admin/, async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    // Supprimer le message de commande
    try {
        await bot.deleteMessage(chatId, msg.message_id);
    } catch (error) {}

    if (!admins.has(userId)) {
        await sendNewMessage(chatId, '❌ Vous n\'êtes pas autorisé à accéder au menu administrateur.');
        return;
    }

    await sendNewMessage(chatId, '🔧 Menu Administrateur', {
        reply_markup: getAdminKeyboard()
    });
});

// Gestion des callbacks
bot.on('callback_query', async (callbackQuery) => {
    const chatId = callbackQuery.message.chat.id;
    const messageId = callbackQuery.message.message_id;
    const userId = callbackQuery.from.id;
    const data = callbackQuery.data;

    // Répondre au callback pour éviter le spinner
    await bot.answerCallbackQuery(callbackQuery.id);

    // Vérifier les permissions admin pour les actions admin
    if (data.startsWith('admin_') && !admins.has(userId)) {
        await bot.answerCallbackQuery(callbackQuery.id, {
            text: '❌ Vous n\'êtes pas autorisé à effectuer cette action.',
            show_alert: true
        });
        return;
    }

    try {
        switch (data) {
            case 'info':
                // Afficher les informations
                const infoOptions = {
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [[
                            { text: '⬅️ Retour', callback_data: 'back_to_main' }
                        ]]
                    }
                };
                
                if (config.welcomeImage) {
                    const imagePath = getImagePath(config.welcomeImage);
                    if (fs.existsSync(imagePath)) {
                        await sendNewPhoto(chatId, imagePath, {
                            caption: config.infoText,
                            ...infoOptions
                        });
                    } else {
                        await updateMessage(chatId, messageId, config.infoText, infoOptions);
                    }
                } else {
                    await updateMessage(chatId, messageId, config.infoText, infoOptions);
                }
                break;

            case 'back_to_main':
                await sendWelcomeMessage(chatId, messageId, callbackQuery.from);
                break;

            case 'admin_menu':
                await updateMessage(chatId, messageId, '🔧 Menu Administrateur', {
                    reply_markup: getAdminKeyboard()
                });
                break;

            case 'admin_edit_welcome':
                userStates[userId] = { action: 'editing_welcome', messageId: messageId };
                const currentWelcome = config.welcomeMessage || 'Aucun message configuré';
                await updateMessage(chatId, messageId, 
                    `📝 **Message d'accueil actuel:**\n\n${currentWelcome}\n\n` +
                    `💡 **Variables disponibles:**\n` +
                    `• \`{firstname}\` - Prénom de l'utilisateur\n` +
                    `• \`{lastname}\` - Nom de famille\n` +
                    `• \`{username}\` - @username\n` +
                    `• \`{fullname}\` - Nom complet\n\n` +
                    `📌 **Exemple:** Bienvenue {firstname} ! 👋\n\n` +
                    `_Envoyez le nouveau message d'accueil pour le remplacer_`, {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [[
                            { text: '❌ Annuler', callback_data: 'admin_menu' }
                        ]]
                    }
                });
                break;

            case 'admin_edit_photo':
                userStates[userId] = { action: 'editing_photo', messageId: messageId };
                await updateMessage(chatId, messageId, '🖼️ Envoyez la nouvelle photo d\'accueil:', {
                    reply_markup: {
                        inline_keyboard: [[
                            { text: '❌ Annuler', callback_data: 'admin_menu' }
                        ]]
                    }
                });
                break;

            case 'admin_edit_miniapp':
                userStates[userId] = { action: 'editing_miniapp_name', messageId: messageId };
                const currentMiniApp = config.miniApp ? 
                    `Nom: ${config.miniApp.text || 'Non défini'}\nURL: ${config.miniApp.url || 'Non défini'}` : 
                    'Aucune mini application configurée';
                await updateMessage(chatId, messageId, 
                    `📱 **Mini Application actuelle:**\n\n${currentMiniApp}\n\n` +
                    `💡 *Entrez le nom du bouton pour la mini application*`, {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [[
                            { text: '❌ Annuler', callback_data: 'admin_menu' }
                        ]]
                    }
                });
                break;

            case 'admin_manage_social':
                await updateMessage(chatId, messageId, '🌐 Gestion des réseaux sociaux', {
                    reply_markup: getSocialManageKeyboard(config)
                });
                break;

            case 'admin_add_social':
                userStates[userId] = { action: 'adding_social_name', messageId: messageId };
                await updateMessage(chatId, messageId, '➕ Entrez le nom du réseau social:', {
                    reply_markup: {
                        inline_keyboard: [[
                            { text: '❌ Annuler', callback_data: 'admin_manage_social' }
                        ]]
                    }
                });
                break;

            case 'admin_edit_info':
                userStates[userId] = { action: 'editing_info', messageId: messageId };
                const currentInfo = config.infoText || 'Aucune information configurée';
                await updateMessage(chatId, messageId, 
                    `ℹ️ **Informations actuelles:**\n\n${currentInfo}\n\n` +
                    `💡 *Envoyez le nouveau texte pour remplacer les informations*`, {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [[
                            { text: '❌ Annuler', callback_data: 'admin_menu' }
                        ]]
                    }
                });
                break;

            case 'admin_broadcast':
                userStates[userId] = { action: 'broadcast_message', messageId: messageId };
                await updateMessage(chatId, messageId, '📢 Envoyez le message à diffuser à tous les utilisateurs:', {
                    reply_markup: {
                        inline_keyboard: [[
                            { text: '❌ Annuler', callback_data: 'admin_menu' }
                        ]]
                    }
                });
                break;

            case 'admin_social_layout':
                await updateMessage(chatId, messageId, '📐 Choisissez le nombre de boutons par ligne:', {
                    reply_markup: getSocialLayoutKeyboard()
                });
                break;

            case 'admin_manage_admins':
                const adminsList = await Promise.all(Array.from(admins).map(async (id) => {
                    try {
                        const chat = await bot.getChat(id);
                        const name = chat.first_name + (chat.last_name ? ` ${chat.last_name}` : '');
                        const username = chat.username ? `@${chat.username}` : '';
                        if (id === ADMIN_ID) {
                            return `👑 **${name}**${username ? ` (${username})` : ''}\n   └─ ID: \`${id}\` _(Principal)_`;
                        }
                        return `👤 **${name}**${username ? ` (${username})` : ''}\n   └─ ID: \`${id}\``;
                    } catch (error) {
                        if (id === ADMIN_ID) return `👑 ID: \`${id}\` _(Principal)_`;
                        return `👤 ID: \`${id}\``;
                    }
                }));
                
                const adminCount = admins.size;
                const adminMessage = `👥 **Gestion des Administrateurs**\n\n` +
                    `📊 Total: ${adminCount} administrateur${adminCount > 1 ? 's' : ''}\n\n` +
                    `**Liste des administrateurs:**\n${adminsList.join('\n\n')}`;
                
                await updateMessage(chatId, messageId, adminMessage, {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '➕ Ajouter un admin', callback_data: 'admin_add_admin' }],
                            [{ text: '➖ Retirer un admin', callback_data: 'admin_remove_admin' }],
                            [{ text: '⬅️ Retour', callback_data: 'admin_menu' }]
                        ]
                    }
                });
                break;

            case 'admin_add_admin':
                userStates[userId] = { action: 'adding_admin', messageId: messageId };
                await updateMessage(chatId, messageId, 
                    `👤 **Ajouter un nouvel administrateur**\n\n` +
                    `📝 Envoyez l'ID Telegram du nouvel administrateur\n\n` +
                    `💡 _Pour obtenir l'ID d'un utilisateur, il doit d'abord démarrer le bot avec /start_`, {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [[
                            { text: '❌ Annuler', callback_data: 'admin_manage_admins' }
                        ]]
                    }
                });
                break;

            case 'admin_remove_admin':
                if (admins.size <= 1) {
                    await bot.answerCallbackQuery(callbackQuery.id, {
                        text: '⚠️ Il doit y avoir au moins un administrateur!',
                        show_alert: true
                    });
                    break;
                }
                
                const removableAdmins = Array.from(admins).filter(id => id !== ADMIN_ID);
                if (removableAdmins.length === 0) {
                    await bot.answerCallbackQuery(callbackQuery.id, {
                        text: '⚠️ Aucun admin supprimable. L\'admin principal ne peut pas être retiré.',
                        show_alert: true
                    });
                    break;
                }
                
                const removeButtons = removableAdmins.map(id => [{
                    text: `❌ Retirer ${id}`,
                    callback_data: `remove_admin_${id}`
                }]);
                
                await updateMessage(chatId, messageId, '👥 Sélectionnez l\'admin à retirer:', {
                    reply_markup: {
                        inline_keyboard: [
                            ...removeButtons,
                            [{ text: '⬅️ Retour', callback_data: 'admin_manage_admins' }]
                        ]
                    }
                });
                break;

            case 'admin_stats':
                // Si c'est une actualisation, afficher une notification
                if (data === 'admin_stats' && callbackQuery.message.text && callbackQuery.message.text.includes('Statistiques du Bot')) {
                    await bot.answerCallbackQuery(callbackQuery.id, {
                        text: '✅ Statistiques actualisées!',
                        show_alert: false
                    });
                }
                
                // Calculer les statistiques
                const totalUsers = users.size;
                const totalAdmins = admins.size;
                const regularUsers = totalUsers - totalAdmins;
                
                // Obtenir la date de démarrage du bot (à partir du premier utilisateur ou maintenant)
                const now = new Date();
                const startTime = botStartTime || now;
                const uptime = now - startTime;
                const uptimeDays = Math.floor(uptime / (1000 * 60 * 60 * 24));
                const uptimeHours = Math.floor((uptime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const uptimeMinutes = Math.floor((uptime % (1000 * 60 * 60)) / (1000 * 60));
                
                // Créer le message de statistiques
                const statsMessage = `📊 **Statistiques du Bot**\n\n` +
                    `👥 **Utilisateurs**\n` +
                    `├─ Total: ${totalUsers}\n` +
                    `├─ Utilisateurs réguliers: ${regularUsers}\n` +
                    `└─ Administrateurs: ${totalAdmins}\n\n` +
                    `⏱️ **Temps de fonctionnement**\n` +
                    `└─ ${uptimeDays}j ${uptimeHours}h ${uptimeMinutes}m\n\n` +
                    `📅 **Dernière actualisation**\n` +
                    `└─ ${now.toLocaleString('fr-FR', { timeZone: 'Europe/Paris' })}\n\n` +
                    `💾 **Données**\n` +
                    `├─ Réseaux sociaux: ${config.socialNetworks ? config.socialNetworks.length : 0}\n` +
                    `└─ Message d'accueil: ${config.welcomeMessage ? 'Configuré ✅' : 'Non configuré ❌'}`;
                
                await updateMessage(chatId, messageId, statsMessage, {
                    parse_mode: 'Markdown',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: '🔄 Actualiser', callback_data: 'admin_stats' }],
                            [{ text: '📥 Exporter les utilisateurs', callback_data: 'admin_export_users' }],
                            [{ text: '⬅️ Retour', callback_data: 'admin_menu' }]
                        ]
                    }
                });
                break;

            case 'admin_export_users':
                // Créer une liste détaillée des utilisateurs
                const usersDetails = await Promise.all(Array.from(users).map(async (userId) => {
                    try {
                        const userChat = await bot.getChat(userId);
                        const isAdmin = admins.has(userId);
                        const firstName = userChat.first_name || '';
                        const lastName = userChat.last_name || '';
                        const username = userChat.username ? `@${userChat.username}` : 'Pas de username';
                        const fullName = `${firstName} ${lastName}`.trim() || 'Sans nom';
                        
                        return `ID: ${userId}${isAdmin ? ' [ADMIN]' : ''}\n` +
                               `Nom: ${fullName}\n` +
                               `Username: ${username}\n` +
                               `Type: ${userChat.type}\n` +
                               `----------------------------`;
                    } catch (error) {
                        // Si on ne peut pas obtenir les infos (utilisateur a bloqué le bot)
                        return `ID: ${userId}${admins.has(userId) ? ' [ADMIN]' : ''}\n` +
                               `Status: Utilisateur inaccessible (a peut-être bloqué le bot)\n` +
                               `----------------------------`;
                    }
                }));
                
                // Créer le contenu du fichier avec des statistiques
                const exportDate = new Date().toLocaleString('fr-FR', { timeZone: 'Europe/Paris' });
                const totalUsersCount = users.size;
                const totalAdminsCount = admins.size;
                const regularUsersCount = totalUsersCount - totalAdminsCount;
                
                const fileContent = `📊 EXPORT DES UTILISATEURS DU BOT\n` +
                    `📅 Date d'export: ${exportDate}\n` +
                    `============================\n\n` +
                    `STATISTIQUES:\n` +
                    `- Total utilisateurs: ${totalUsersCount}\n` +
                    `- Utilisateurs réguliers: ${regularUsersCount}\n` +
                    `- Administrateurs: ${totalAdminsCount}\n` +
                    `============================\n\n` +
                    `LISTE DÉTAILLÉE:\n\n` +
                    usersDetails.join('\n\n');
                
                // Envoyer le fichier
                await bot.sendDocument(chatId, Buffer.from(fileContent, 'utf-8'), {
                    filename: `users_export_${new Date().toISOString().split('T')[0]}.txt`,
                    caption: `📥 **Export complet des utilisateurs**\n\n` +
                             `📊 Total: ${totalUsersCount} utilisateurs\n` +
                             `👤 Réguliers: ${regularUsersCount}\n` +
                             `👑 Admins: ${totalAdminsCount}`
                }, {
                    parse_mode: 'Markdown'
                });
                break;

            case 'admin_close':
                await deleteActiveMessage(chatId);
                break;

            case 'cancel':
                delete userStates[userId];
                await bot.answerCallbackQuery(callbackQuery.id, {
                    text: '❌ Action annulée',
                    show_alert: false
                });
                break;

            default:
                // Gestion de la suppression des réseaux sociaux
                if (data.startsWith('admin_delete_social_')) {
                    const index = parseInt(data.replace('admin_delete_social_', ''));
                    if (config.socialNetworks && config.socialNetworks[index]) {
                        config.socialNetworks.splice(index, 1);
                        saveConfig(config);
                        await bot.answerCallbackQuery(callbackQuery.id, {
                            text: '✅ Réseau social supprimé!',
                            show_alert: true
                        });
                        await bot.editMessageReplyMarkup(getSocialManageKeyboard(config), {
                            chat_id: chatId,
                            message_id: messageId
                        });
                    }
                }
                // Gestion de la disposition des boutons sociaux
                else if (data.startsWith('social_layout_')) {
                    const buttonsPerRow = parseInt(data.replace('social_layout_', ''));
                    config.socialButtonsPerRow = buttonsPerRow;
                    saveConfig(config);
                    await bot.answerCallbackQuery(callbackQuery.id, {
                        text: `✅ Disposition mise à jour: ${buttonsPerRow} bouton(s) par ligne`,
                        show_alert: true
                    });
                    await updateMessage(chatId, messageId, '🌐 Gestion des réseaux sociaux', {
                        reply_markup: getSocialManageKeyboard(config)
                    });
                }
                // Gestion de la suppression des admins
                else if (data.startsWith('remove_admin_')) {
                    const adminToRemove = parseInt(data.replace('remove_admin_', ''));
                    if (admins.has(adminToRemove) && adminToRemove !== ADMIN_ID) {
                        admins.delete(adminToRemove);
                        saveAdmins();
                        await bot.answerCallbackQuery(callbackQuery.id, {
                            text: '✅ Administrateur retiré!',
                            show_alert: true
                        });
                        // Retour à la liste des admins
                        const adminsList = Array.from(admins).map(id => {
                            if (id === ADMIN_ID) return `👑 ${id} (Principal)`;
                            return `👤 ${id}`;
                        }).join('\n');
                        
                        await updateMessage(chatId, messageId, `👥 Administrateurs actuels:\n\n${adminsList}`, {
                            reply_markup: {
                                inline_keyboard: [
                                    [{ text: '➕ Ajouter un admin', callback_data: 'admin_add_admin' }],
                                    [{ text: '➖ Retirer un admin', callback_data: 'admin_remove_admin' }],
                                    [{ text: '⬅️ Retour', callback_data: 'admin_menu' }]
                                ]
                            }
                        });
                    }
                }
                break;
        }
    } catch (error) {
        console.error('Erreur lors du traitement du callback:', error);
        await bot.answerCallbackQuery(callbackQuery.id, {
            text: '❌ Une erreur s\'est produite',
            show_alert: true
        });
    }
});

// Gestion des messages texte
bot.on('message', async (msg) => {
    // Ignorer les commandes
    if (msg.text && msg.text.startsWith('/')) return;

    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const userState = userStates[userId];

    if (!userState) return;

    // Supprimer le message de l'utilisateur pour garder le chat propre
    try {
        await bot.deleteMessage(chatId, msg.message_id);
    } catch (error) {}

    try {
        switch (userState.action) {
            case 'editing_welcome':
                config.welcomeMessage = msg.text;
                saveConfig(config);
                delete userStates[userId];
                await updateMessage(chatId, userState.messageId, '✅ Message d\'accueil mis à jour!');
                
                // Retour automatique au menu après 2 secondes
                setTimeout(async () => {
                    await updateMessage(chatId, userState.messageId, '🔧 Menu Administrateur', {
                        reply_markup: getAdminKeyboard()
                    });
                }, 2000);
                break;

            case 'editing_info':
                config.infoText = msg.text;
                saveConfig(config);
                delete userStates[userId];
                await updateMessage(chatId, userState.messageId, '✅ Texte d\'informations mis à jour!');
                
                // Retour automatique au menu après 2 secondes
                setTimeout(async () => {
                    await updateMessage(chatId, userState.messageId, '🔧 Menu Administrateur', {
                        reply_markup: getAdminKeyboard()
                    });
                }, 2000);
                break;

            case 'editing_miniapp_name':
                if (!config.miniApp) {
                    config.miniApp = {};
                }
                config.miniApp.text = msg.text;
                userStates[userId] = { 
                    action: 'editing_miniapp_url', 
                    messageId: userState.messageId 
                };
                await updateMessage(chatId, userState.messageId, '📱 Entrez l\'URL de la mini application (ou "supprimer" pour la retirer):', {
                    reply_markup: {
                        inline_keyboard: [[
                            { text: '❌ Annuler', callback_data: 'admin_menu' }
                        ]]
                    }
                });
                break;

            case 'editing_miniapp_url':
                if (msg.text.toLowerCase() === 'supprimer') {
                    config.miniApp.url = null;
                } else {
                    config.miniApp.url = msg.text;
                }
                saveConfig(config);
                delete userStates[userId];
                await updateMessage(chatId, userState.messageId, '✅ Mini application mise à jour!', {
                    reply_markup: getAdminKeyboard()
                });
                break;

            case 'adding_social_name':
                userStates[userId] = { 
                    action: 'adding_social_url',
                    socialName: msg.text,
                    messageId: userState.messageId
                };
                await updateMessage(chatId, userState.messageId, '🔗 Entrez l\'URL du réseau social:', {
                    reply_markup: {
                        inline_keyboard: [[
                            { text: '❌ Annuler', callback_data: 'admin_manage_social' }
                        ]]
                    }
                });
                break;

            case 'adding_social_url':
                userStates[userId] = {
                    ...userState,
                    action: 'adding_social_emoji',
                    socialUrl: msg.text
                };
                await updateMessage(chatId, userState.messageId, '😀 Entrez un emoji pour ce réseau social (ou envoyez "skip" pour utiliser 🔗):', {
                    reply_markup: {
                        inline_keyboard: [[
                            { text: '❌ Annuler', callback_data: 'admin_manage_social' }
                        ]]
                    }
                });
                break;

            case 'adding_social_emoji':
                const emoji = msg.text.toLowerCase() === 'skip' ? '🔗' : msg.text;
                if (!config.socialNetworks) {
                    config.socialNetworks = [];
                }
                config.socialNetworks.push({
                    name: userState.socialName,
                    url: userState.socialUrl,
                    emoji: emoji
                });
                saveConfig(config);
                delete userStates[userId];
                await updateMessage(chatId, userState.messageId, '✅ Réseau social ajouté!', {
                    reply_markup: getSocialManageKeyboard(config)
                });
                break;

            case 'broadcast_message':
                const message = msg.text;
                let successCount = 0;
                let failCount = 0;
                let blockedCount = 0;
                
                await updateMessage(chatId, userState.messageId, '📤 Préparation de l\'envoi...\n⏳ Cela peut prendre quelques minutes pour respecter les limites Telegram.');
                
                // Configuration pour respecter les limites Telegram
                const MESSAGES_PER_SECOND = 25; // Limite sécurisée (Telegram permet 30/sec)
                const BATCH_SIZE = 25; // Nombre de messages par batch
                const BATCH_DELAY = 1100; // Délai entre les batches (1.1 seconde)
                const ERROR_RETRY_DELAY = 5000; // Délai après une erreur 429 (5 secondes)
                
                // Convertir Set en Array pour pouvoir faire des batches
                const targetUsers = Array.from(users).filter(uid => !admins.has(uid));
                const totalUsers = targetUsers.length;
                
                // Diviser les utilisateurs en batches
                for (let i = 0; i < targetUsers.length; i += BATCH_SIZE) {
                    const batch = targetUsers.slice(i, i + BATCH_SIZE);
                    const batchPromises = [];
                    
                    for (const targetUserId of batch) {
                        const sendPromise = bot.sendMessage(
                            targetUserId, 
                            `📢 <b>Message de l'administrateur:</b>\n\n${message}`,
                            { parse_mode: 'HTML' }
                        ).then(() => {
                            successCount++;
                        }).catch(async (error) => {
                            // Gestion spécifique des erreurs Telegram
                            if (error.response && error.response.statusCode === 429) {
                                // Too Many Requests - attendre avant de réessayer
                                console.log('⚠️ Rate limit atteint, pause de 5 secondes...');
                                await new Promise(resolve => setTimeout(resolve, ERROR_RETRY_DELAY));
                                
                                // Réessayer une fois après le délai
                                try {
                                    await bot.sendMessage(targetUserId, `📢 <b>Message de l'administrateur:</b>\n\n${message}`, { parse_mode: 'HTML' });
                                    successCount++;
                                } catch (retryError) {
                                    failCount++;
                                    console.error(`Échec définitif pour l'utilisateur ${targetUserId}:`, retryError.message);
                                }
                            } else if (error.response && error.response.statusCode === 403) {
                                // L'utilisateur a bloqué le bot
                                blockedCount++;
                            } else {
                                failCount++;
                                console.error(`Erreur envoi à ${targetUserId}:`, error.message);
                            }
                        });
                        
                        batchPromises.push(sendPromise);
                    }
                    
                    // Attendre que tous les messages du batch soient traités
                    await Promise.all(batchPromises);
                    
                    // Mettre à jour le statut après chaque batch
                    const progress = Math.round(((i + batch.length) / totalUsers) * 100);
                    await updateMessage(chatId, userState.messageId, 
                        `📤 Envoi en cours...\n\n` +
                        `📊 Progression: ${progress}%\n` +
                        `✅ Envoyés: ${successCount}\n` +
                        `❌ Échecs: ${failCount}\n` +
                        `🚫 Bloqués: ${blockedCount}\n\n` +
                        `⏳ Veuillez patienter...`
                    );
                    
                    // Attendre avant le prochain batch (sauf pour le dernier)
                    if (i + BATCH_SIZE < targetUsers.length) {
                        await new Promise(resolve => setTimeout(resolve, BATCH_DELAY));
                    }
                }
                
                delete userStates[userId];
                
                // Message final avec statistiques complètes
                let statusEmoji = '✅';
                let statusText = 'Message diffusé avec succès!';
                
                if (failCount > totalUsers * 0.3) {
                    statusEmoji = '⚠️';
                    statusText = 'Diffusion terminée avec des erreurs';
                } else if (failCount > 0) {
                    statusEmoji = '✅';
                    statusText = 'Diffusion terminée';
                }
                
                await updateMessage(chatId, userState.messageId, 
                    `${statusEmoji} <b>${statusText}</b>\n\n` +
                    `📊 <b>Statistiques détaillées:</b>\n` +
                    `👥 Utilisateurs ciblés: ${totalUsers}\n` +
                    `✅ Messages envoyés: ${successCount}\n` +
                    `❌ Échecs techniques: ${failCount}\n` +
                    `🚫 Utilisateurs ayant bloqué le bot: ${blockedCount}\n\n` +
                    `💡 <i>Conseil: Les utilisateurs qui ont bloqué le bot ne recevront plus de messages.</i>`,
                    {
                        reply_markup: getAdminKeyboard(),
                        parse_mode: 'HTML'
                    }
                );
                break;

            case 'adding_admin':
                const newAdminId = parseInt(msg.text);
                if (isNaN(newAdminId)) {
                    await bot.answerCallbackQuery(callbackQuery.id, {
                        text: '❌ ID invalide. Veuillez entrer un nombre.',
                        show_alert: true
                    });
                    break;
                }
                
                if (admins.has(newAdminId)) {
                    await bot.answerCallbackQuery(callbackQuery.id, {
                        text: '⚠️ Cet utilisateur est déjà administrateur!',
                        show_alert: true
                    });
                } else {
                    // Vérifier si l'utilisateur existe
                    try {
                        const newAdminChat = await bot.getChat(newAdminId);
                        const newAdminName = newAdminChat.first_name + (newAdminChat.last_name ? ` ${newAdminChat.last_name}` : '');
                        const newAdminUsername = newAdminChat.username ? `@${newAdminChat.username}` : '';
                        
                        admins.add(newAdminId);
                        saveAdmins();
                        delete userStates[userId];
                        
                        // Notifier le nouvel administrateur
                        try {
                            await bot.sendMessage(newAdminId, 
                                `🎉 **Félicitations!**\n\n` +
                                `Vous avez été promu administrateur du bot.\n` +
                                `Utilisez /admin pour accéder au menu administrateur.`, 
                                { parse_mode: 'Markdown' }
                            );
                        } catch (error) {
                            // L'utilisateur n'a peut-être pas démarré le bot
                        }
                        
                        const adminsList = await Promise.all(Array.from(admins).map(async (id) => {
                            try {
                                const chat = await bot.getChat(id);
                                const name = chat.first_name + (chat.last_name ? ` ${chat.last_name}` : '');
                                const username = chat.username ? `@${chat.username}` : '';
                                if (id === ADMIN_ID) {
                                    return `👑 **${name}**${username ? ` (${username})` : ''}\n   └─ ID: \`${id}\` _(Principal)_`;
                                }
                                return `👤 **${name}**${username ? ` (${username})` : ''}\n   └─ ID: \`${id}\``;
                            } catch (error) {
                                if (id === ADMIN_ID) return `👑 ID: \`${id}\` _(Principal)_`;
                                return `👤 ID: \`${id}\``;
                            }
                        }));
                        
                        const adminCount = admins.size;
                        await updateMessage(chatId, userState.messageId, 
                            `✅ **Administrateur ajouté avec succès!**\n\n` +
                            `👤 **Nouvel admin:** ${newAdminName}${newAdminUsername ? ` (${newAdminUsername})` : ''}\n\n` +
                            `📊 Total: ${adminCount} administrateur${adminCount > 1 ? 's' : ''}\n\n` +
                            `**Liste des administrateurs:**\n${adminsList.join('\n\n')}`, {
                            parse_mode: 'Markdown',
                            reply_markup: {
                                inline_keyboard: [
                                    [{ text: '➕ Ajouter un admin', callback_data: 'admin_add_admin' }],
                                    [{ text: '➖ Retirer un admin', callback_data: 'admin_remove_admin' }],
                                    [{ text: '⬅️ Retour', callback_data: 'admin_menu' }]
                                ]
                            }
                        });
                    } catch (error) {
                        await updateMessage(chatId, userState.messageId, 
                            `❌ **Erreur**\n\n` +
                            `Impossible de trouver l'utilisateur avec l'ID: ${newAdminId}\n` +
                            `Assurez-vous que l'utilisateur a démarré le bot avec /start`, {
                            parse_mode: 'Markdown',
                            reply_markup: {
                                inline_keyboard: [[
                                    { text: '⬅️ Retour', callback_data: 'admin_manage_admins' }
                                ]]
                            }
                        });
                    }
                }
                break;
        }
    } catch (error) {
        console.error('Erreur lors du traitement du message:', error);
        await sendNewMessage(chatId, '❌ Une erreur s\'est produite. Veuillez réessayer.');
    }
});

// Gestion des photos
bot.on('photo', async (msg) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const userState = userStates[userId];

    if (!userState || userState.action !== 'editing_photo') return;

    // Supprimer le message de photo pour garder le chat propre
    try {
        await bot.deleteMessage(chatId, msg.message_id);
    } catch (error) {}

    try {
        // Obtenir la photo de meilleure qualité
        const photo = msg.photo[msg.photo.length - 1];
        const fileId = photo.file_id;

        // Télécharger la photo
        const file = await bot.getFile(fileId);
        const filePath = file.file_path;
        const downloadUrl = `https://api.telegram.org/file/bot${process.env.BOT_TOKEN}/${filePath}`;

        // Sauvegarder la photo
        const fileName = `welcome_${Date.now()}.jpg`;
        const localPath = path.join(IMAGES_DIR, fileName);

        const https = require('https');
        const fileStream = fs.createWriteStream(localPath);

        https.get(downloadUrl, (response) => {
            response.pipe(fileStream);
            fileStream.on('finish', async () => {
                fileStream.close();
                
                // Supprimer l'ancienne photo si elle existe
                if (config.welcomeImage) {
                    const oldPath = getImagePath(config.welcomeImage);
                    if (fs.existsSync(oldPath)) {
                        fs.unlinkSync(oldPath);
                    }
                }

                // Mettre à jour la configuration
                config.welcomeImage = fileName;
                saveConfig(config);
                delete userStates[userId];

                await updateMessage(chatId, userState.messageId, '✅ Photo d\'accueil mise à jour!', {
                    reply_markup: getAdminKeyboard()
                });
            });
        });
    } catch (error) {
        console.error('Erreur lors du traitement de la photo:', error);
        await sendNewMessage(chatId, '❌ Une erreur s\'est produite lors du traitement de la photo.');
    }
});

// Gestion des erreurs globales
bot.on('error', (error) => {
    console.error('Erreur bot:', error);
});

bot.on('webhook_error', (error) => {
    console.error('Erreur webhook:', error);
});

// Gestion de l'arrêt propre
process.on('SIGTERM', async () => {
    console.log('⚠️ SIGTERM reçu, arrêt en cours...');
    
    if (keepAliveInterval) {
        clearInterval(keepAliveInterval);
    }
    
    try {
        await bot.deleteWebHook();
        await mongoose.connection.close();
    } catch (error) {
        console.error('Erreur lors de l\'arrêt:', error);
    }
    
    process.exit(0);
});

// Démarrer le serveur Express
app.listen(PORT, '0.0.0.0', () => {
    console.log(`🌐 Serveur démarré sur le port ${PORT}`);
    console.log(`📍 URL webhook: ${WEBHOOK_URL}${WEBHOOK_PATH}`);
    console.log(`🔧 ID Admin: ${ADMIN_ID}`);
    
    // Initialiser le bot après le démarrage du serveur
    initializeBot();
});